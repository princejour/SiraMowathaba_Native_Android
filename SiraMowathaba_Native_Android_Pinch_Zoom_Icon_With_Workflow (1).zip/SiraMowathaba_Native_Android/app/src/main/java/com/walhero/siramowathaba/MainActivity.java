package com.walhero.siramowathaba;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.InputType;
import android.view.*;
import android.view.ScaleGestureDetector;
import android.graphics.Matrix;
import android.view.Gravity;
import android.webkit.WebView;
import android.widget.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.Collator;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private DB db;
    private LinearLayout root, listLayout, statsLayout, calendarLayout, bodyLayout;
    private FrameLayout zoomViewport;
    private ScaleGestureDetector scaleDetector;
    private float screenScale = 1f, translateX = 0f, translateY = 0f;
    private float lastTouchX = 0f, lastTouchY = 0f;
    private boolean draggingScreen = false;
    private Spinner classSpinner;
    private TextView title, studentTitle, yearButton;
    private Button reportButton, importButton, holidaysButton, renameButton, printButton, clearButton;
    private String schoolYear = "2025 - 2026";
    private String selectedClass = "";
    private String selectedStudent = "";
    private final String[] months = {"أكتوبر","نوفمبر","ديسمبر","جانفي","فيفري","مارس","أفريل","ماي"};
    private final Map<String,Integer> monthIndex = new HashMap<>();
    private final Map<String,List<String>> defaultClasses = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(30,27,75));
        db = new DB(this);
        initMonths();
        initDefaults();
        db.seedDefaults(defaultClasses);
        schoolYear = db.getSetting("school_year", "2025 - 2026");
        db.seedDefaultHolidaysIfEmpty(schoolYear);
        buildUI();
        refreshClasses();
    }


    private void resetScreenZoom(){
        screenScale = 1f;
        translateX = 0f;
        translateY = 0f;
        applyScreenTransform();
    }

    private void applyScreenTransform(){
        if(bodyLayout == null) return;
        bodyLayout.setScaleX(screenScale);
        bodyLayout.setScaleY(screenScale);
        bodyLayout.setTranslationX(translateX);
        bodyLayout.setTranslationY(translateY);
    }

    private boolean handleZoomPanTouch(android.view.MotionEvent event){
        if(bodyLayout == null) return false;

        if(scaleDetector != null) scaleDetector.onTouchEvent(event);

        if(event.getPointerCount() >= 2){
            draggingScreen = false;
            return true;
        }

        if(screenScale <= 1.01f){
            if(event.getActionMasked() == android.view.MotionEvent.ACTION_UP && event.getEventTime() - event.getDownTime() < 180){
                return false;
            }
            return false;
        }

        switch(event.getActionMasked()){
            case android.view.MotionEvent.ACTION_DOWN:
                lastTouchX = event.getRawX();
                lastTouchY = event.getRawY();
                draggingScreen = true;
                return true;

            case android.view.MotionEvent.ACTION_MOVE:
                if(draggingScreen){
                    float dx = event.getRawX() - lastTouchX;
                    float dy = event.getRawY() - lastTouchY;
                    translateX += dx;
                    translateY += dy;
                    limitScreenTranslation();
                    applyScreenTransform();
                    lastTouchX = event.getRawX();
                    lastTouchY = event.getRawY();
                    return true;
                }
                break;

            case android.view.MotionEvent.ACTION_UP:
            case android.view.MotionEvent.ACTION_CANCEL:
                draggingScreen = false;
                return true;
        }
        return false;
    }

    private void limitScreenTranslation(){
        if(zoomViewport == null || bodyLayout == null) return;
        float maxX = Math.max(0, (bodyLayout.getWidth() * screenScale - zoomViewport.getWidth()) / 2f + dp(80));
        float maxY = Math.max(0, (bodyLayout.getHeight() * screenScale - zoomViewport.getHeight()) / 2f + dp(120));

        if(translateX > maxX) translateX = maxX;
        if(translateX < -maxX) translateX = -maxX;
        if(translateY > maxY) translateY = maxY;
        if(translateY < -maxY) translateY = -maxY;
    }

    private void initMonths(){
        monthIndex.put("جانفي",0); monthIndex.put("فيفري",1); monthIndex.put("مارس",2); monthIndex.put("أفريل",3);
        monthIndex.put("ماي",4); monthIndex.put("جوان",5); monthIndex.put("جويلية",6); monthIndex.put("أوت",7);
        monthIndex.put("سبتمبر",8); monthIndex.put("أكتوبر",9); monthIndex.put("نوفمبر",10); monthIndex.put("ديسمبر",11);
    }

    private void initDefaults(){
        defaultClasses.put("8 أساسي 9", Arrays.asList("ادم الظاهري","ادم سامي همامي","امنة شرميطي","امنة المزوغي","اية الرياحي","احمد الجديدي","احمد براء غاقي","احمد بن عثمان","انس البوغانمي","اسراء النفيسي","اسراء عيساوي","جهاد العياري","حمزة العياري","سيرين النفوطي","سيرين ضيفي","عبد الرحمان شرميطي","فرح مصباح","لجين التليلي","محمد  فارس الحسني","ملاك الصديق","ملاك عكازي","ميار البكوش","مسلم بالزين","نور الرياحي","يحي حميه","ياسمينة صوفيا نيكول الهمامي","يوسف الشارني"));
        defaultClasses.put("8 أساسي 8", Arrays.asList("رانية عمران","ادم النابلي","الاء الجندوبي","الاء ضيفي","امان الله الطرابلسي","ايوب الباجي","اسامة النصايبي","انس الجعيدي","اسراء النفوطي","ايلاف الزمالي","حسين عبد اللطيف","حمزة بوغانمي","دعاء ضيفي","رحاب خليفي","ريهام عباسي","راما الزعيم","زكريا بن يونس التيواجني","سفيان الذوادي","سيف الله الدريدي","شذى الزناقي","عادل بوغانمي","عبد الرحمان شعباني","فاطمة بوسعيد","محمد عزيز الصايم","مرام بن ابراهيم","مريم صحراوي","معاذ عيساوي","ملاك توتي","ياسمين بوغانمي","يوسف شبشوب","يوسف السنوسي","يوسف مرزوقي"));
        defaultClasses.put("8 أساسي 7", Arrays.asList("ادم سليمان","الاء الرحمان فايدي","امان الله النفيسي","امان الله الورهاني","احمد رزق","انس بريكي","اسراء عوايطي","اسلام الدريدي","اياد قنواتي","راما الهاشمي","رحمة بن طلحة","ريان الزهمولي","زكرياء الصابري","سيرين بوعبيد","ساجد مولهي","شهد ورفلي","غسان كرماوي","فردوس بن سلامه","محمد امين الشارني","محمد الزيات","محمدامين العوني","محمد امين الفيتوري","نور الهدى المجدوب","نادر حباسي","هبة هرماسي","وايل الخذيري","يسرى المجدوب","يحي مرايدي"));
        defaultClasses.put("8 أساسي 6", Arrays.asList("ادم الطريفي","الاء الماجري","الاء بنعلي","اسراء الكلابي","بيرم ساحلي","تسنيم الفرجاني","رفاء بنعمار","ريان بنمحرز","زكريا الكوكي","سيف الدين كثيري","غفران عبيد","محمد ميسر حناشي","مريم خليفي","ملاك الحكيري","منيار البحري","مهاب المنزلي","محمد اياد السايح","نوران صمامه","نور الدريدي","هبة الرحمان الفني","ياسمين الفني","يمنى الرميلي","يوسف العمدوني","يوسف معيز","يوسف فريضي","يوسف حشاني","يوسف فرحاتي"));
    }

    private void buildUI(){
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.rgb(248,250,252));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(12), dp(12), dp(12), dp(8));
        header.setBackgroundColor(Color.WHITE);

        title = tv("منظومة السيرة والمواظبة", 18, Color.rgb(30,41,59), true);
        title.setGravity(Gravity.CENTER);
        header.addView(title, lp(-1,-2));

        TextView sub = tv("قيم مرشد: وليد بن جماعة", 12, Color.rgb(100,116,139), true);
        sub.setGravity(Gravity.CENTER);
        header.addView(sub);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER);
        topRow.setPadding(0, dp(8), 0, 0);

        yearButton = tv("السنة الدراسية: " + schoolYear, 13, Color.WHITE, true);
        yearButton.setGravity(Gravity.CENTER);
        yearButton.setPadding(dp(10), dp(8), dp(10), dp(8));
        yearButton.setBackgroundColor(Color.rgb(79,70,229));
        yearButton.setOnClickListener(v -> changeSchoolYear());
        topRow.addView(yearButton, lp(0, -2, 1));

        holidaysButton = btn("لصق قائمة العطل");
        holidaysButton.setOnClickListener(v -> pasteHolidaysDialog());
        topRow.addView(holidaysButton, lp(0, -2, 1));

        header.addView(topRow);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(0, dp(8), 0, 0);

        classSpinner = new Spinner(this);
        classSpinner.setTextDirection(View.TEXT_DIRECTION_RTL);
        controls.addView(classSpinner, lp(0, -2, 1));

        importButton = btn("استيراد");
        importButton.setOnClickListener(v -> importDialog());
        controls.addView(importButton, lp(0, -2, 1));

        header.addView(controls);
        root.addView(header);

        zoomViewport = new FrameLayout(this);
        zoomViewport.setBackgroundColor(Color.rgb(248,250,252));
        zoomViewport.setClipChildren(true);
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override
            public boolean onScale(ScaleGestureDetector detector){
                screenScale *= detector.getScaleFactor();
                if(screenScale < 0.70f) screenScale = 0.70f;
                if(screenScale > 2.50f) screenScale = 2.50f;
                limitScreenTranslation();
                applyScreenTransform();
                return true;
            }
        });
        zoomViewport.setOnTouchListener((v, event) -> handleZoomPanTouch(event));

        bodyLayout = new LinearLayout(this);
        bodyLayout.setOrientation(LinearLayout.VERTICAL);
        bodyLayout.setPadding(dp(8), dp(8), dp(8), dp(20));
        bodyLayout.setPivotX(0);
        bodyLayout.setPivotY(0);

        zoomViewport.addView(bodyLayout, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        ));
        LinearLayout body = bodyLayout;

        listLayout = new LinearLayout(this);
        listLayout.setOrientation(LinearLayout.VERTICAL);
        body.addView(listLayout);

        studentTitle = tv("اختر تلميذًا", 17, Color.rgb(15,23,42), true);
        studentTitle.setGravity(Gravity.CENTER);
        studentTitle.setPadding(0, dp(10), 0, dp(6));
        body.addView(studentTitle);

        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        renameButton = btn("إصلاح الاسم");
        renameButton.setOnClickListener(v -> renameStudent());
        printButton = btn("طباعة");
        printButton.setOnClickListener(v -> printStudent());
        clearButton = btn("مسح السجل");
        clearButton.setOnClickListener(v -> clearStudentLog());
        actionRow.addView(renameButton, lp(0,-2,1));
        actionRow.addView(printButton, lp(0,-2,1));
        actionRow.addView(clearButton, lp(0,-2,1));
        body.addView(actionRow);

        statsLayout = new LinearLayout(this);
        statsLayout.setOrientation(LinearLayout.VERTICAL);
        body.addView(statsLayout);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        calendarLayout = new LinearLayout(this);
        calendarLayout.setOrientation(LinearLayout.VERTICAL);
        hsv.addView(calendarLayout);
        body.addView(hsv);

        root.addView(zoomViewport, lp(-1,0,1));
        setContentView(root);

        classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id){
                selectedClass = String.valueOf(classSpinner.getSelectedItem());
                selectedStudent = "";
                refreshStudents();
                buildCalendar();
            }
            public void onNothingSelected(AdapterView<?> p){}
        });
    }

    private TextView tv(String s,int sp,int color,boolean bold){
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        return t;
    }
    private Button btn(String s){
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextDirection(View.TEXT_DIRECTION_RTL);
        return b;
    }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams lp(int w,int h,float weight){ return new LinearLayout.LayoutParams(w,h,weight); }
    private int dp(int v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private void refreshClasses(){
        List<String> classes = db.getClasses();
        Collections.sort(classes, this::compareClasses);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, classes);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        classSpinner.setAdapter(ad);
    }

    private int compareClasses(String a, String b){
        List<Integer> na = nums(a), nb = nums(b);
        int n = Math.max(na.size(), nb.size());
        for(int i=0;i<n;i++){
            if(i>=na.size()) return 1;
            if(i>=nb.size()) return -1;
            if(!na.get(i).equals(nb.get(i))) return na.get(i)-nb.get(i);
        }
        return a.compareTo(b);
    }
    private List<Integer> nums(String s){
        ArrayList<Integer> out = new ArrayList<>();
        Matcher m = Pattern.compile("\\d+").matcher(s);
        while(m.find()) out.add(Integer.parseInt(m.group()));
        return out;
    }

    private void refreshStudents(){
        listLayout.removeAllViews();
        if(selectedClass == null || selectedClass.isEmpty()) return;
        for(String name: db.getStudents(selectedClass)){
            TextView row = tv(name, 15, Color.rgb(30,41,59), true);
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            row.setBackgroundColor(Color.WHITE);
            row.setOnClickListener(v -> {
                selectedStudent = name;
                studentTitle.setText(name + " — " + selectedClass);
                refreshStats();
                buildCalendar();
            });
            listLayout.addView(row, lp(-1,-2));
        }
    }

    private void refreshStats(){
        statsLayout.removeAllViews();
        if(selectedStudent.isEmpty()) return;
        Stats s = db.stats(selectedStudent, schoolYear, months, this::isClosedDay);
        statsLayout.addView(tv("أيام الغياب: " + s.days + " | ساعات: " + s.hours + " | مبررة: " + s.justified + " | غير مبررة: " + s.unjustified, 14, Color.rgb(15,23,42), true));
    }

    private void buildCalendar(){
        calendarLayout.removeAllViews();
        applyScreenTransform();
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.addView(dayCell("الشهر", true, false, ""));
        for(int d=1; d<=31; d++) head.addView(dayCell(String.valueOf(d), true, false, ""));
        calendarLayout.addView(head);

        if(selectedStudent.isEmpty()) return;
        for(String m: months){
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(dayCell(m, true, false, ""));
            int max = getDaysInMonth(m);
            for(int d=1; d<=31; d++){
                if(d>max){ row.addView(dayCell("", false, true, "")); continue; }
                Holiday h = db.getHoliday(schoolYear,m,d);
                boolean sunday = isSunday(m,d);
                if(h != null || sunday){
                    String label = h != null ? h.label : "";
                    row.addView(dayCell(label, false, true, label));
                }else{
                    String mark = db.getAbsence(selectedStudent, m, d);
                    String just = db.getJustif(selectedStudent, m, d);
                    TextView c = dayCell(markToSymbol(mark) + (just.isEmpty() ? "" : "\n" + just), false, false, "");
                    final String fm=m; final int fd=d;
                    c.setOnClickListener(v -> editAbsence(fm,fd));
                    row.addView(c);
                }
            }
            calendarLayout.addView(row);
        }
    }

    private TextView dayCell(String text, boolean header, boolean holiday, String label){
        TextView c = tv(text, header ? 10 : 9, Color.rgb(15,23,42), header || holiday);
        c.setGravity(Gravity.CENTER);
        c.setMinWidth(dp(38));
        c.setMinHeight(dp(38));
        c.setMaxLines(3);
        c.setPadding(dp(1), dp(1), dp(1), dp(1));
        if(header) c.setBackgroundColor(Color.rgb(243,244,246));
        else if(holiday) c.setBackgroundColor(Color.rgb(226,232,240));
        else c.setBackgroundColor(Color.WHITE);
        return c;
    }

    private String markToSymbol(String m){
        if(m.equals("plus")) return "+";
        if(m.equals("am")) return "—";
        if(m.equals("pm")) return "—";
        if(m.equals("h1")) return "●";
        if(m.equals("h2")) return "●●";
        return "";
    }

    private interface ClosedChecker{ boolean check(String m,int d); }
    private boolean isClosedDay(String m,int d){ return db.getHoliday(schoolYear,m,d)!=null || isSunday(m,d); }

    private int yearStart(){ return parseYears()[0]; }
    private int yearEnd(){ return parseYears()[1]; }
    private int[] parseYears(){
        Matcher mm = Pattern.compile("(\\d{4}).*?(\\d{4})").matcher(schoolYear);
        if(mm.find()) return new int[]{Integer.parseInt(mm.group(1)), Integer.parseInt(mm.group(2))};
        return new int[]{2025,2026};
    }
    private int getYearForMonth(String m){
        return (m.equals("أكتوبر") || m.equals("نوفمبر") || m.equals("ديسمبر")) ? yearStart() : yearEnd();
    }
    private boolean isSunday(String m,int d){
        Calendar cal = Calendar.getInstance();
        cal.set(getYearForMonth(m), monthIndex.get(m), d);
        return cal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY;
    }
    private int getDaysInMonth(String m){
        Calendar cal = Calendar.getInstance();
        cal.set(getYearForMonth(m), monthIndex.get(m), 1);
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    private void editAbsence(String m,int d){
        final String[] labels = {"غياب كامل","صباحي","مسائي","ساعة","ساعتان","إلغاء"};
        final String[] vals = {"plus","am","pm","h1","h2",""};
        new AlertDialog.Builder(this)
                .setTitle(d + " " + m)
                .setItems(labels, (di, which) -> {
                    db.saveAbsence(selectedStudent,m,d,vals[which], db.getJustif(selectedStudent,m,d));
                    justifyDialog(m,d);
                }).show();
    }
    private void justifyDialog(String m,int d){
        final String[] labels = {"بدون تبرير","حو: حضور ولي","شط: شهادة طبية"};
        final String[] vals = {"","حو","شط"};
        new AlertDialog.Builder(this).setTitle("التبرير")
                .setItems(labels, (di, which)->{
                    db.saveAbsence(selectedStudent,m,d,db.getAbsence(selectedStudent,m,d),vals[which]);
                    refreshStats(); buildCalendar();
                }).show();
    }

    private void changeSchoolYear(){
        EditText e = new EditText(this);
        e.setText(schoolYear);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        new AlertDialog.Builder(this).setTitle("تغيير السنة الدراسية")
                .setView(e)
                .setPositiveButton("حفظ", (d,w)->{
                    schoolYear = e.getText().toString().trim();
                    db.setSetting("school_year", schoolYear);
                    db.seedDefaultHolidaysIfEmpty(schoolYear);
                    yearButton.setText("السنة الدراسية: " + schoolYear);
                    refreshStats(); buildCalendar();
                }).setNegativeButton("إلغاء", null).show();
    }

    private void pasteHolidaysDialog(){
        EditText e = new EditText(this);
        e.setMinLines(8);
        e.setGravity(Gravity.RIGHT|Gravity.TOP);
        e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setHint("مثال:\nعطلة الشتاء:\nديسمبر: 17, 22-31\nجانفي: 1-4\n\nعيد الشهداء:\nأفريل: 9");
        new AlertDialog.Builder(this).setTitle("لصق قائمة العطل")
                .setView(e)
                .setPositiveButton("حفظ وتحديث", (d,w)->{
                    db.clearHolidays(schoolYear);
                    parseAndSaveHolidays(e.getText().toString());
                    refreshStats(); buildCalendar();
                }).setNegativeButton("إلغاء", null).show();
    }

    private void parseAndSaveHolidays(String text){
        String currentLabel = "";
        for(String raw: text.split("\\n")){
            String line = raw.trim();
            if(line.isEmpty()) continue;
            if(line.endsWith(":") && !line.contains(",")){
                currentLabel = line.substring(0,line.length()-1).trim();
                continue;
            }
            String[] parts = line.split(":",2);
            if(parts.length==2){
                String month = normalizeMonth(parts[0].trim());
                if(month == null) continue;
                String days = parts[1];
                for(String token: days.split(",")){
                    token = token.trim();
                    if(token.contains("-")){
                        String[] ab = token.split("-");
                        if(ab.length==2){
                            int a = parseInt(ab[0]), b = parseInt(ab[1]);
                            for(int i=Math.min(a,b); i<=Math.max(a,b); i++) if(i>0) db.addHoliday(schoolYear,month,i,currentLabel);
                        }
                    }else{
                        int day = parseInt(token);
                        if(day>0) db.addHoliday(schoolYear,month,day,currentLabel);
                    }
                }
            }
        }
    }

    private String normalizeMonth(String s){
        for(String m: months) if(s.contains(m)) return m;
        return null;
    }
    private int parseInt(String s){ try{return Integer.parseInt(s.replaceAll("[^0-9]",""));}catch(Exception e){return -1;} }

    private void importDialog(){
        EditText e = new EditText(this);
        e.setMinLines(8);
        e.setGravity(Gravity.RIGHT|Gravity.TOP);
        e.setHint("الصيغة:\nالقسم | اسم التلميذ\n8 أساسي 1 | أحمد بن علي\n8 1 | محمد...");
        new AlertDialog.Builder(this).setTitle("استيراد القوائم")
                .setView(e)
                .setPositiveButton("استيراد وإضافة", (d,w)->{
                    importText(e.getText().toString());
                    refreshClasses();
                }).setNegativeButton("إلغاء", null).show();
    }
    private void importText(String text){
        for(String raw: text.split("\\n")){
            String line = raw.trim();
            if(line.isEmpty()) continue;
            String[] p = line.split("[|;,\\t]",2);
            if(p.length<2) continue;
            String cls = normalizeClass(p[0].trim());
            String name = p[1].trim();
            if(!cls.isEmpty() && !name.isEmpty()) db.addStudent(cls,name);
        }
    }
    private String normalizeClass(String s){
        s = s.replace("الثامنة","8").replace("ثامنة","8").replace("الثامن","8").replace("ثامن","8");
        s = s.replace("أساسي"," ").replace("اساسي"," ");
        Matcher m = Pattern.compile("(\\d+)").matcher(s);
        ArrayList<String> ns = new ArrayList<>();
        while(m.find()) ns.add(m.group(1));
        if(ns.size()>=2 && ns.get(0).equals("8")) return "8 أساسي " + Integer.parseInt(ns.get(1));
        if(ns.size()==1 && ns.get(0).equals("8")) return "8 أساسي";
        return s.trim();
    }

    private void renameStudent(){
        if(selectedStudent.isEmpty()) return;
        EditText e = new EditText(this);
        e.setText(selectedStudent);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        new AlertDialog.Builder(this).setTitle("إصلاح اسم التلميذ")
                .setView(e)
                .setPositiveButton("حفظ", (d,w)->{
                    String n = e.getText().toString().trim();
                    if(!n.isEmpty()){
                        db.renameStudent(selectedClass, selectedStudent, n);
                        db.renameAbsences(selectedStudent,n);
                        selectedStudent=n;
                        studentTitle.setText(n + " — " + selectedClass);
                        refreshStudents(); buildCalendar();
                    }
                }).setNegativeButton("إلغاء", null).show();
    }

    private void clearStudentLog(){
        if(selectedStudent.isEmpty()) return;
        new AlertDialog.Builder(this).setTitle("مسح السجل")
                .setMessage("مسح كل غيابات هذا التلميذ؟")
                .setPositiveButton("مسح", (d,w)->{ db.clearStudentAbsences(selectedStudent); refreshStats(); buildCalendar(); })
                .setNegativeButton("إلغاء", null).show();
    }

    private void printStudent(){
        if(selectedStudent.isEmpty()) return;
        WebView web = new WebView(this);
        web.loadDataWithBaseURL(null, printHtml(), "text/html", "UTF-8", null);
        web.postDelayed(() -> {
            PrintManager pm = (PrintManager)getSystemService(PRINT_SERVICE);
            pm.print("سجل غيابات " + selectedStudent, web.createPrintDocumentAdapter("سجل"), new PrintAttributes.Builder().build());
        }, 800);
    }
    private String printHtml(){
        StringBuilder sb = new StringBuilder();
        sb.append("<html dir='rtl'><head><meta charset='utf-8'><style>");
        sb.append("body{font-family:sans-serif;padding:16px}table{border-collapse:collapse;width:100%;table-layout:fixed}td,th{border:1px solid #000;text-align:center;height:28px;font-size:9px}.h{background:#e2e8f0;font-weight:bold}.m{font-weight:bold;background:#f3f4f6}.title{text-align:center;font-weight:bold;font-size:18px;margin-bottom:12px}");
        sb.append("</style></head><body>");
        sb.append("<div class='title'>بطاقة السيرة والمواظبة السنوية</div>");
        sb.append("<p><b>السنة الدراسية:</b> ").append(schoolYear).append(" &nbsp; <b>القسم:</b> ").append(selectedClass).append(" &nbsp; <b>التلميذ:</b> ").append(selectedStudent).append("</p>");
        sb.append("<table><tr><th>الشهر</th>");
        for(int d=1; d<=31; d++) sb.append("<th>").append(d).append("</th>");
        sb.append("</tr>");
        for(String m: months){
            sb.append("<tr><td class='m'>").append(m).append("</td>");
            int max = getDaysInMonth(m);
            for(int d=1; d<=31; d++){
                if(d>max){ sb.append("<td class='h'></td>"); continue; }
                Holiday h = db.getHoliday(schoolYear,m,d);
                if(h!=null || isSunday(m,d)){
                    String label = h!=null ? h.label : "";
                    sb.append("<td class='h'>").append(label).append("</td>");
                }else{
                    String mark = markToSymbol(db.getAbsence(selectedStudent,m,d));
                    String just = db.getJustif(selectedStudent,m,d);
                    sb.append("<td>").append(mark).append(just.isEmpty()?"":"<br>"+just).append("</td>");
                }
            }
            sb.append("</tr>");
        }
        sb.append("</table><p style='margin-top:30px'>إمضاء القيم المرشد: وليد بن جماعة</p>");
        sb.append("</body></html>");
        return sb.toString();
    }

    static class Holiday{ String label; Holiday(String l){label=l==null?"":l;} }
    static class Stats{ double days; int hours, justified, unjustified; }

    static class DB extends SQLiteOpenHelper {
        DB(Context c){ super(c,"sira_mowathaba_native.db",null,1); }
        public void onCreate(SQLiteDatabase x){
            x.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,class TEXT,name TEXT,UNIQUE(class,name))");
            x.execSQL("CREATE TABLE absences(id INTEGER PRIMARY KEY AUTOINCREMENT,student TEXT,month TEXT,day INTEGER,absence TEXT,justif TEXT,UNIQUE(student,month,day))");
            x.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");
            x.execSQL("CREATE TABLE holidays(id INTEGER PRIMARY KEY AUTOINCREMENT,year TEXT,month TEXT,day INTEGER,label TEXT,UNIQUE(year,month,day))");
        }
        public void onUpgrade(SQLiteDatabase db,int o,int n){}
        void seedDefaults(Map<String,List<String>> map){
            SQLiteDatabase w=getWritableDatabase();
            for(String c: map.keySet()) for(String s: map.get(c)) addStudent(c,s);
        }
        void addStudent(String c,String n){ getWritableDatabase().execSQL("INSERT OR IGNORE INTO students(class,name) VALUES(?,?)",new Object[]{c,n}); }
        List<String> getClasses(){
            ArrayList<String> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT DISTINCT class FROM students",null);
            while(c.moveToNext()) out.add(c.getString(0)); c.close(); return out;
        }
        List<String> getStudents(String cls){
            ArrayList<String> out=new ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT name FROM students WHERE class=? ORDER BY name",new String[]{cls});
            while(c.moveToNext()) out.add(c.getString(0)); c.close(); return out;
        }
        void renameStudent(String cls,String old,String n){ getWritableDatabase().execSQL("UPDATE students SET name=? WHERE class=? AND name=?",new Object[]{n,cls,old}); }
        void renameAbsences(String old,String n){ getWritableDatabase().execSQL("UPDATE absences SET student=? WHERE student=?",new Object[]{n,old}); }
        void saveAbsence(String st,String m,int d,String a,String j){ getWritableDatabase().execSQL("INSERT OR REPLACE INTO absences(student,month,day,absence,justif) VALUES(?,?,?,?,?)",new Object[]{st,m,d,a,j}); }
        String getAbsence(String st,String m,int d){ return one("SELECT absence FROM absences WHERE student=? AND month=? AND day=?",new String[]{st,m,String.valueOf(d)}); }
        String getJustif(String st,String m,int d){ return one("SELECT justif FROM absences WHERE student=? AND month=? AND day=?",new String[]{st,m,String.valueOf(d)}); }
        String one(String sql,String[] args){ Cursor c=getReadableDatabase().rawQuery(sql,args); String v=""; if(c.moveToFirst()) v=c.getString(0)==null?"":c.getString(0); c.close(); return v; }
        void clearStudentAbsences(String s){ getWritableDatabase().execSQL("DELETE FROM absences WHERE student=?",new Object[]{s}); }
        void setSetting(String k,String v){ getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v}); }
        String getSetting(String k,String def){ String v=one("SELECT v FROM settings WHERE k=?",new String[]{k}); return v.isEmpty()?def:v; }
        void addHoliday(String y,String m,int d,String l){ getWritableDatabase().execSQL("INSERT OR REPLACE INTO holidays(year,month,day,label) VALUES(?,?,?,?)",new Object[]{y,m,d,l}); }
        void clearHolidays(String y){ getWritableDatabase().execSQL("DELETE FROM holidays WHERE year=?",new Object[]{y}); }
        Holiday getHoliday(String y,String m,int d){ String v=one("SELECT label FROM holidays WHERE year=? AND month=? AND day=?",new String[]{y,m,String.valueOf(d)}); return v.isEmpty()?null:new Holiday(v); }
        void seedDefaultHolidaysIfEmpty(String y){
            Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM holidays WHERE year=?",new String[]{y});
            c.moveToFirst(); int count=c.getInt(0); c.close(); if(count>0) return;
            addHoliday(y,"أكتوبر",15,"عيد الجلاء");
            for(int d=27;d<=31;d++) addHoliday(y,"أكتوبر",d,"عطلة نصف الثلاثي الأول");
            addHoliday(y,"نوفمبر",1,"عطلة نصف الثلاثي الأول"); addHoliday(y,"نوفمبر",2,"عطلة نصف الثلاثي الأول");
            addHoliday(y,"ديسمبر",17,"عيد الثورة");
            for(int d=22;d<=31;d++) addHoliday(y,"ديسمبر",d,"عطلة الشتاء");
            for(int d=1;d<=4;d++) addHoliday(y,"جانفي",d,"عطلة الشتاء");
            for(int d=2;d<=8;d++) addHoliday(y,"فيفري",d,"عطلة نصف الثلاثي الثاني");
            for(int d=16;d<=29;d++) addHoliday(y,"مارس",d,"عطلة الربيع");
            addHoliday(y,"أفريل",9,"عيد الشهداء");
            addHoliday(y,"ماي",1,"عيد الشغل");
        }
        Stats stats(String st,String year,String[] months, ClosedChecker checker){
            Stats s=new Stats();
            int rawHours=0;
            Cursor c=getReadableDatabase().rawQuery("SELECT month,day,absence,justif FROM absences WHERE student=?",new String[]{st});
            while(c.moveToNext()){
                String m=c.getString(0); int d=c.getInt(1); String a=c.getString(2); String j=c.getString(3);
                if(checker.check(m,d)) continue;
                if("plus".equals(a)) s.days+=1; else if("am".equals(a)||"pm".equals(a)) s.days+=.5; else if("h1".equals(a)) rawHours+=1; else if("h2".equals(a)) rawHours+=2;
                if(("حو".equals(j)||"شط".equals(j)) && a!=null && !a.isEmpty()) s.justified++;
            }
            c.close();
            s.days += rawHours/6; s.hours=rawHours%6;
            s.unjustified = Math.max(0, (int)Math.ceil(s.days) + (s.hours>0?1:0) - s.justified);
            return s;
        }
    }
}